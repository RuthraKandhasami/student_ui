﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Student
    {
        public int Rollno { get; set; }
        public string Fname { get; set; }
        public string Gender { get; set; }
        public DateTime Dob { get; set; }
        public string Mobno { get; set; }
        public string Email { get; set; }
        public string Com_Address { get; set; }
        public string S_State { get; set; }
    }
}
