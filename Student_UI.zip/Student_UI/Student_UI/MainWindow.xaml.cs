﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS_BAL;
using SMS_DAL;
using SMS_Exceptions;
using Entities;

namespace Student_UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentBAL studentbl = new StudentBAL();

        public MainWindow()
        {
            InitializeComponent();
            studentbl = new StudentBAL();
        }

        public bool ValidateUI(string fname, string dob,string mno)
        {
            bool sts = true;
            StringBuilder sb = new StringBuilder();
            {
                if (fname == null || fname == string.Empty)
                    sb.Append("FULL NAME MUST NOT BE EMPTY" + Environment.NewLine);
            }
            {
                if (dob == null || dob == string.Empty)
                    sb.Append("FULL NAME MUST NOT BE EMPTY" + Environment.NewLine);
            }
            if (mno == null || mno == string.Empty)
                sb.Append("FULL NAME MUST NOT BE EMPTY" + Environment.NewLine);
            if (fname == null || fname == string.Empty)
                sb.Append("FULL NAME MUST NOT BE EMPTY" + Environment.NewLine);

            if (sts == false)
                throw new SMSExceptions(sb.ToString());
            return sts;
        }
        private void Mobno_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Listbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    if (ValidateUI(fname.Text, dob.SelectedDate.ToString(), mno.Text, email.Text, state.Text)
            Student student = new Student
            {
                Fname = fname.Text,
                Dob = (DateTime)dob.SelectedDate,
                Mobno = mno.Text,
                Email = email.Text,
                S_State = ((ListBoxItem)state.SelectedItem).Content.ToString()
            };
            string Gender = string.Empty;
            if (m.IsChecked == true)
                Gender = m.Content.ToString();
            else if (f.IsChecked == true)
                Gender = f.Content.ToString();
            student.Gender = Gender;
            addr.SelectAll();
            student.Com_Address = addr.Selection.Text;
            studentbl.Add(student);

            MessageBox.Show("Inserted Successfully");
        }

        
        //    else 
        //    {
        //        MessageBox.Show("");

        //    }
        //}
        //catch(SMSExceptions ex)
        //    {

    }

    
}
