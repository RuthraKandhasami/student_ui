﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using SMS_DAL;
using SMS_Exceptions;
using Entities;
namespace SMS_DAL
{
    public class StudentDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser");
        }
        public void Insert(Student student)
        {
            //try
            //{
            cmd = new SqlCommand("insert into [189824].Student values(@Name,@Gender,@DOB,@Contact,@Email,@Address,@State)", cn);
            cmd.Parameters.AddWithValue("@Name", student.Fname);
            cmd.Parameters.AddWithValue("@Gender", student.Gender);
            cmd.Parameters.AddWithValue("@DOB", student.Dob);
            cmd.Parameters.AddWithValue("@Contact", student.Mobno);
            cmd.Parameters.AddWithValue("@Email", student.Email);
            cmd.Parameters.AddWithValue("@Address", student.Com_Address);
            cmd.Parameters.AddWithValue("@State", student.S_State);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }
        //catch(Exception)
        //{
        //    throw;
        //}
        //finally
        //{
        //    if(cn.State)
        //}


        public void Update(Student student)
        {
            cmd = new SqlCommand("update [189824].Student set(@Name,@Gender,@DOB,@Contact,@Email,@Address,@State)", cn);
            cmd.Parameters.AddWithValue("@Name", student.Fname);
            cmd.Parameters.AddWithValue("@Gender", student.Gender);
            cmd.Parameters.AddWithValue("@DOB", student.Dob);
            cmd.Parameters.AddWithValue("@Contact", student.Mobno);
            cmd.Parameters.AddWithValue("@Email", student.Email);
            cmd.Parameters.AddWithValue("@Address", student.Com_Address);
            cmd.Parameters.AddWithValue("@State", student.S_State);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }
    }

}
